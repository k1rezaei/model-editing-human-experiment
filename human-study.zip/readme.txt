please run this command first:

Python2:
python -m SimpleHTTPServer

Python3:
python3 -m http.server
--------------------------------

Open main.html
There 150 tests that you should answer.

For each test:
(1) Wait for both images to get loaded.
(2) Read the question carefully as it changes in different tests.
(3) Give us your rating in the scale of 1 to 5.
    This can be done by pressing keys "1", "2", "3", "4", and "5".
(4) Click on Next (this can be done by pressing "n")

Don't forget to save your progress (this can be done by pressing "s") quite often. Otherwise you have do the whole process over and over again -:)
Each time you save, a file will be downloaded.
In order to resume from your checkpoints, please rename last checkpoint to 'log.json' and replace the old file in this directory with that checkpoint.


Don't be worried that your rating might be biassed, we will hopefully debias it later.

Send us your last saved log.
